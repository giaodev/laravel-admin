<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class NT extends Model
{
    protected $table = "nt";
}
